from setuptools import setup

setup(
	name='helloworld-script',
	version='0.1',
	scripts=['helloworld.py']
)
